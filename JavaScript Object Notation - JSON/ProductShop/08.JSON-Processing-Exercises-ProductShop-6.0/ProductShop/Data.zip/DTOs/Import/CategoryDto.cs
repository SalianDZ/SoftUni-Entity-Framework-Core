﻿namespace ProductShop.DTOs.Import
{
    public class CategoryDto
    {
        public string Name { get; set; } = null!;
    }
}
