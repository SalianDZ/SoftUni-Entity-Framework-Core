﻿using Newtonsoft.Json;

namespace ProductShop.DTOs.Import
{
    public class CategoryProductDto
    {
        public int CategoryId { get; set; }

        public int ProductId { get; set; }
    }
}
