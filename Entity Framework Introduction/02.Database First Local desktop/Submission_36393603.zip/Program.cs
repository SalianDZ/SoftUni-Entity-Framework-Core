﻿using SoftUni.Data;

SoftUniContext softUniContext = new SoftUniContext();
Console.WriteLine("Connection success!!!");